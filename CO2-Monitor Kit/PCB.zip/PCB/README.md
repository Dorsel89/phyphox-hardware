# phyphox CO₂-Monitor

Platinendesign für einen phyphox-fähigen CO₂-Monitor. Das Modul besteht im wesentlichen aus:
- RGB-LED: WP154A4SEJ3VBDZGW/CA
- BLE Mikrocontroller: ESP32-DEVKITC-32D
- Sensor: SCD30
